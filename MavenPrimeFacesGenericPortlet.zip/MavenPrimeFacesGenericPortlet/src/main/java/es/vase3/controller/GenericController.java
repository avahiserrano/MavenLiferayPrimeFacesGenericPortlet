/**
 * 
 */
package es.vase3.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;

import org.apache.log4j.Logger;

import es.vase3.dto.GenericDTO;
import es.vase3.pojos.AnotherPojo;
import es.vase3.pojos.Pojo;
import es.vase3.dto.Dto;
/**
 * @author aurelio
 *
 */
@ManagedBean(name = "genericController")
@SessionScoped
public class GenericController implements Serializable {

	private static final long serialVersionUID = -3868891741172703029L;
	private GenericDTO<Dto> dto = GenericDTO.getInstance(Dto.class);
	final static Logger logger = Logger.getLogger(GenericController.class);
	
	public GenericController() {
		Pojo p = new Pojo();
		Pojo p2 = new Pojo();

		// POPULATE dto MEMBERS... or add another objects members to dto...
		p.setValue("This is the value");
		p2.setValue("Second value");
		this.dto.set("POJO", p);
		this.dto.set("ANOTHER_POJO", new AnotherPojo());
		ArrayList<Pojo> list = new ArrayList<Pojo>();
		list.add(p);
		list.add(p2);
		this.dto.set("GENERIC_LIST", list);
		this.dto.set("GENERIC_MAP", new HashMap<Integer, AnotherPojo>());

	}
	public GenericDTO<Dto> getDto() {
		return dto;
	}
	public void setDto(GenericDTO<Dto> dto) {
		this.dto = dto;
	}
	// Actions, ActionsListener, Ajax listener, ....
    public void keyUp(javax.faces.event.AjaxBehaviorEvent event) {
    	// For test : log for items 0 and 1
    	logger.info(((List<Pojo>)this.dto.get("GENERIC_LIST")).get(0).getValue());
    	logger.info(((List<Pojo>)this.dto.get("GENERIC_LIST")).get(1).getValue());
    }

	public void actionListener(ActionEvent event){
    	// For test : log for items 0 and 1
    	logger.info(((List<Pojo>)this.dto.get("GENERIC_LIST")).get(0).getValue());
    	logger.info(((List<Pojo>)this.dto.get("GENERIC_LIST")).get(1).getValue());				
	}
}
