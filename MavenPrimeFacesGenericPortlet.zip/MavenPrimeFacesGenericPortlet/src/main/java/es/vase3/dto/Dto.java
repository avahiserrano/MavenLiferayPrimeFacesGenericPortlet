package es.vase3.dto;

import java.util.List;
import java.util.Map;

import es.vase3.dto.Attribute;
import es.vase3.dto.GenericDto;
import es.vase3.pojos.AnotherPojo;
import es.vase3.pojos.Pojo;

// This is the Generic Dto for this portlet
public interface Dto extends GenericDto {
    public static final Attribute<GenericDto, Pojo> pojo = Attribute.getInstance("POJO");
    public static final Attribute<GenericDto, AnotherPojo> anotherPojo = Attribute.getInstance("ANOTHER_POJO");
    public static final Attribute<GenericDto, List<?>> genericList = Attribute.getInstance("GENERIC_LIST");
    public static final Attribute<GenericDto, Map<?, ?>> genericHashMap = Attribute.getInstance("GENERIC_MAP");
}
