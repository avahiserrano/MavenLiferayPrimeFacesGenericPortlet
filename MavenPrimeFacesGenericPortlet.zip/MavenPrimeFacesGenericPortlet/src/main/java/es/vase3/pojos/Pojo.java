package es.vase3.pojos;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Pojo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -5082847542279994179L;
	private String value = "";
	private List<AnotherPojo> anotherValue = new ArrayList<AnotherPojo>();

	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public List<AnotherPojo> getAnotherValue() {
		return anotherValue;
	}
	public void setAnotherValue(List<AnotherPojo> anotherValue) {
		this.anotherValue = anotherValue;
	}
}
